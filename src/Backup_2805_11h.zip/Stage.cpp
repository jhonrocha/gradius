/*
 * Stage.cpp
 *
 *  Created on: 27/05/2013
 *      Author: jhonantans
 */

#include "Stage.h"

Stage::Stage(string path, string title): Screen(path, title) {
	background.move(screen);

}

Stage::~Stage() {
	// TODO
}

