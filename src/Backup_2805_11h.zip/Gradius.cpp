/*
 * Gradius.cpp
 *
 *  Created on: 27/05/2013
 *      Author: jhonantans
 */

#include "Background.h"
#include "Boss.h"
#include "Bullet.h"
#include "Double.h"
#include "Enemy.h"
#include "Entity.h"
#include "GradiusShip.h"
#include "Screen.h"
#include "Shoot.h"
#include "Simple.h"
#include "SimpleEnemy.h"
#include "Sprite.h"
#include "SquadEnemy.h"
#include "Stage.h"
#include "Timer.h"
#include "WinScreen.h"

int main(){
	//TODO Main
	return 0;
}
