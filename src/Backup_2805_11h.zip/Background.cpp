/*
 * Background.cpp
 *
 *  Created on: 25/05/2013
 *      Author: jhonantans
 */

#include "Background.h"

Background::Background(string path, int x, int y):Sprite(path) {
	this->x = x;
	this->y = y;
	xVel = 10;
}

Background::~Background() {
	// TODO Auto-generated destructor stub
}

void Background::move(SDL_Surface* screen){
	//Scroll background
	x -= xVel;
	if( x <= -width ) {
		x = 0;
	}
	show(x,y,screen);
	show(x+width,y,screen);
}

void Background::setXVel(int xVel){
	this->xVel = xVel;
}
int Background::getXVel(){
	return xVel;
}

void Background::setx(int x){
	this->x = x;
}
int Background::getx(){
	return x;
}

void Background::sety(int y){
	this->y = y;
}
int Background::gety(){
	return y;
}
