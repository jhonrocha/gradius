/*
 * Shoot.h
 *
 *  Created on: 27/05/2013
 *      Author: raphael
 */

#ifndef SHOOT_H_
#define SHOOT_H_

class Shoot {
public:
	Shoot();
	virtual ~Shoot();
};

#endif /* SHOOT_H_ */
