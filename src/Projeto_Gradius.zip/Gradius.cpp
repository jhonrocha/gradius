/*
 * Gradius.cpp
 *
 *  Created on: 27/05/2013
 *      Author: jhonantans
 */

int main(){
	//TODO Main
	return 0;
}
