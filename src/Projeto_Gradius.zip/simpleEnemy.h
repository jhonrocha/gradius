/*
 * simpleEnemy.h
 *
 *  Created on: 27/05/2013
 *      Author: raphael
 */

#ifndef SIMPLEENEMY_H_
#define SIMPLEENEMY_H_

#include "Enemy.h"

class simpleEnemy: public Enemy{
public:
	simpleEnemy(string,int, int, int, int);
	virtual ~simpleEnemy();
	void shoot();
	void move(int, int);

};

#endif /* SIMPLEENEMY_H_ */
