/*
 * Sprite.cpp
 *
 *  Created on: 26/05/2013
 *      Author: jhonantans
 */

#include "SDL/SDL_image.h"
#include "Sprite.h"

Sprite::Sprite(string path) {
	sprite = IMG_Load(path.c_str());
	width = sprite->w;
	height = sprite->h;
}

Sprite::Sprite(string path, int width, int height) {
	this->width = width;
	this->height = height;
	sprite = IMG_Load(path.c_str());
}

void Sprite::show(int posX, int posY, SDL_Surface* screen, SDL_Rect* clip = NULL){
	SDL_Rect offset;
	offset.x = posX;
	offset.y = posY;
	SDL_BlitSurface(sprite, clip, screen, &offset);
}

void Sprite::load(string path){
	SDL_Surface* temp;
	temp = IMG_Load(path.c_str());
	sprite = SDL_DisplayFormat(temp);
	SDL_FreeSurface(temp);
}

void Sprite::setwidth(int width){
	this->width = width;
}

void Sprite::setheight(int height){
	this->height = height;
}

int Sprite::getwidth(){
	return width;
}

int Sprite::getheight(){
	return height;
}

Sprite::~Sprite() {
	SDL_FreeSurface(sprite);
}
