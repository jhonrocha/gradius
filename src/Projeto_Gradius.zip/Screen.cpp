/*
 * Screen.cpp
 *
 *  Created on: 27/05/2013
 *      Author: jhonantans
 */

#include "Screen.h"

Screen::Screen(string path, string title){
	background(path);
	text(title);
	screen = NULL;
	screen_width = background.width;
	screen_height = background.height;
}

Screen::~Screen() {
	// TODO Auto-generated destructor stub
}

void Screen::setScreenWidth(int screen_width){
	this->screen_width = screen_width;
}

void Screen::setScreenHeight(int screen_height){
	this->screen_height = screen_height;
}

int Screen::getScreenWidth(){
	return screen_width;
}

int Screen::getScreenHeight(){
	return screen_height;
}

void Screen::show_screen(){
	SDL_Flip(screen);
}
