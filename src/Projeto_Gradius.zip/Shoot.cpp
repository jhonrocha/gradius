/*
 * Shoot.cpp
 *
 *  Created on: 27/05/2013
 *      Author: raphael
 */

#include "Shoot.h"

Shoot::Shoot() {
	// TODO Auto-generated constructor stub

}

Shoot::~Shoot() {
	// TODO Auto-generated destructor stub
}

