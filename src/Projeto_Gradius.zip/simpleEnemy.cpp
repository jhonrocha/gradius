/*
 * simpleEnemy.cpp
 *
 *  Created on: 27/05/2013
 *      Author: raphael
 */

#include "simpleEnemy.h"

simpleEnemy::simpleEnemy(string path, int coord_x, int coord_y, int xVel, int yVel):Enemy(path, coord_x, coord_y, xVel, yVel){
	// TODO Auto-generated constructor stub

}

simpleEnemy::~simpleEnemy() {
	// TODO Auto-generated destructor stub
}

void simpleEnemy::shoot(){

}

void simpleEnemy::move(int screenHeight, int screenWidth){
	int upDown = 1;

	x -= xVel;

	yVel = 10*upDown;
	y += yVel;

	if ((y < 30) || (y + screenHeight > screenHeight - 20))
	{
		upDown = upDown * (-1);
		y -= yVel;
	}
	Box.x = x;
	Box.y = y;

}
