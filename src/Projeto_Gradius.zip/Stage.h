/*
 * Stage.h
 *
 *  Created on: 27/05/2013
 *      Author: jhonantans
 */

#ifndef STAGE_H_
#define STAGE_H_

#include "Screen.h"

class Stage: public Screen {
public:
	Stage(string, string);
	virtual ~Stage();
};

#endif /* STAGE_H_ */
